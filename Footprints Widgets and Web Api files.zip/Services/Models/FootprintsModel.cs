﻿using System;
using System.Linq;
using Telerik.Sitefinity.Model;
using Telerik.Sitefinity.DynamicModules.Model;

namespace SitefinityWebApp.Custom.Services.Models
{
    public class FootprintsModel
    {

         //DEFAULT PROPERTIES
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string City { get; set; }
        public string Street { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Country { get; set; }
        public string Name { get; set; }
        public string Author { get; set; }
        public string Details { get; set; }
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
        public string PublicationDate { get; set; }
        public string LastModified { get; set; }
        public string DateCreated { get; set; }

        public FootprintsModel()
        {
        }

        public FootprintsModel(DynamicContent sfFootprintItem)
        {
            var Address = sfFootprintItem.GetAddressFields().First().Value;
            this.Id = sfFootprintItem.Id;
            this.Title = sfFootprintItem.GetValue<Lstring>("Title");
            this.Street = Address.Street;
            this.City = Address.City;
            this.State = Address.StateCode;
            this.Zip = Address.Zip;
            this.Country = Address.CountryCode;
            this.Latitude = Address.Latitude;
            this.Longitude = Address.Longitude;
            this.Details = sfFootprintItem.GetValue<Lstring>("Details");
            this.Author = sfFootprintItem.Author;
            this.Name = sfFootprintItem.GetValue<Lstring>("Name");
            this.PublicationDate = sfFootprintItem.PublicationDate.ToShortDateString();
            this.LastModified = sfFootprintItem.LastModified.ToShortDateString();
            this.DateCreated = sfFootprintItem.DateCreated.ToLongDateString();
        }
    }
}