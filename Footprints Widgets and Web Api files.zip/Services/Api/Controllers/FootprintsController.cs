﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using Telerik.Sitefinity.DynamicModules;
using Telerik.Sitefinity.Utilities.TypeConverters;
using SitefinityWebApp.Custom.Services.Models;
using Telerik.Sitefinity.GenericContent.Model;
using Telerik.Sitefinity.Model;

namespace SitefinityWebApp.Custom.Services.Api.Controllers
{
    public class FootprintsController : ApiController
    {
        private DynamicModuleManager _manager = null;
        private readonly string providerName = "OpenAccessProvider";
        private readonly Type footprintType = TypeResolutionService.ResolveType("Telerik.Sitefinity.DynamicTypes.Model.Footprints.Footprint");

        public DynamicModuleManager Manager
        {
            get
            {
                return _manager ??
                    (_manager = DynamicModuleManager.GetManager(providerName));
            }
        }

        public IEnumerable<FootprintsModel> Get()
        {
            var myCollection = new List<FootprintsModel>();
         
            try 
            {
                this.Manager.GetDataItems(footprintType)
                    .Where(f => f.Status == ContentLifecycleStatus.Live)
                    .OrderByDescending(o => o.DateCreated)
                    .ToList()
                    .ForEach(f => myCollection.Add(new FootprintsModel(f)));
            }
            catch { }
            return myCollection;
        }

        public IEnumerable<FootprintsModel> Get(string id)
        {
            var myCollection = new List<FootprintsModel>();
            try 
            {
                this.Manager.GetDataItems(footprintType)
                    .Where(f => f.Status == ContentLifecycleStatus.Live &&
                        f.GetValue<String>("Name").ToString().ToLower().Trim() == id.ToString().ToLower().Trim())
                    .OrderByDescending(o => o.DateCreated)
                    .ToList()
                    .ForEach(f => myCollection.Add(new FootprintsModel(f)));
            }
            catch { }
            return myCollection;
        }

        public IEnumerable<FootprintsModel> Get(string id, string dateFrom, string dateTo)
        {
            var myCollection = new List<FootprintsModel>();
            DateTime dateValue;

            try
            {
                //We have an all and valid dates
                if (id.ToLower().Trim() == "all" &&
                    DateTime.TryParse(dateFrom, out dateValue) &&
                    DateTime.TryParse(dateTo, out dateValue))
                {
                    this.Manager.GetDataItems(footprintType)
                        .Where(f => f.Status == ContentLifecycleStatus.Live &&
                            f.PublicationDate >= Convert.ToDateTime(dateFrom) &&
                            f.PublicationDate < Convert.ToDateTime(dateTo).AddDays(1))
                        .OrderByDescending(o => o.DateCreated)
                        .ToList()
                        .ForEach(f => myCollection.Add(new FootprintsModel(f)));
                }
                //We have a name and valid dates
                else if (id.ToLower().Trim() != "all" &&
                    DateTime.TryParse(dateFrom, out dateValue) &&
                    DateTime.TryParse(dateTo, out dateValue))
                {
                    this.Manager.GetDataItems(footprintType)
                        .Where(f => f.Status == ContentLifecycleStatus.Live &&
                            f.GetValue<String>("Name").ToString().ToLower().Trim() == id.ToString().ToLower().Trim() &&
                            f.PublicationDate >= Convert.ToDateTime(dateFrom) &&
                            f.PublicationDate < Convert.ToDateTime(dateTo).AddDays(1))
                        .OrderByDescending(o => o.DateCreated)
                        .ToList()
                        .ForEach(f => myCollection.Add(new FootprintsModel(f)));
                }
                //We have invalid/no dates, so just pull all.
                else
                {
                    this.Manager.GetDataItems(footprintType)
                    .Where(f => f.Status == ContentLifecycleStatus.Live)
                    .OrderByDescending(o => o.DateCreated)
                    .ToList()
                    .ForEach(f => myCollection.Add(new FootprintsModel(f)));
                }
            }
            catch { }
            return myCollection;
        }
    }
}