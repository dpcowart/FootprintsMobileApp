﻿using System;
using System.Linq;
using Telerik.Sitefinity.Abstractions;
using Telerik.Sitefinity.Personalization;
using Telerik.Microsoft.Practices.Unity;
using Telerik.Sitefinity.Personalization.Impl;
using System.Web.Routing;
using System.Web.Http;

namespace SitefinityWebApp
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            Telerik.Sitefinity.Abstractions.Bootstrapper.Initialized += Bootstrapper_Initialized;
        }

        protected void Bootstrapper_Initialized(object sender, Telerik.Sitefinity.Data.ExecutedEventArgs args)
        {
            if (args.CommandName == "Bootstrapped")
            {
                ObjectFactory.Container.RegisterType(
                    typeof(ICriterionEvaluator),
                    typeof(CustomEvaluator),
                    PersonalizationConstants.CriteriaName.SearchKeywords,
                    new ContainerControlledLifetimeManager(),
                    new InjectionConstructor());

                if (args.CommandName == "Bootstrapped")
                {
                    RegisterRoutes(RouteTable.Routes);
                }
            }
        }

        /// <summary>
        /// Registers the routes.
        /// </summary>
        /// <param name="routes">The routes.</param>
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.Ignore("{resource}.axd/{*pathInfo}");

            routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{action}/{id}/{dateFrom}/{dateTo}",
                defaults: new { id = RouteParameter.Optional, dateFrom = RouteParameter.Optional, dateTo = RouteParameter.Optional }
            );
        }
    }
}