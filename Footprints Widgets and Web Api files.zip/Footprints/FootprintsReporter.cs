﻿using System;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using Telerik.Sitefinity.Web.UI;
using Telerik.Sitefinity.DynamicModules;
using Telerik.Sitefinity.Model;
using Telerik.Sitefinity.DynamicModules.Model;
using Telerik.Sitefinity.GenericContent.Model;
using Telerik.Sitefinity.Utilities.TypeConverters;
using System.Web;
using Telerik.Sitefinity.Modules.Pages;

namespace SitefinityWebApp.Custom.Footprints
{
    /// <summary>
    /// Class used to create custom page widget
    /// </summary>
    /// <remarks>
    /// If this widget is a part of a Sitefinity module,
    /// you can register it in the site's toolbox by adding this to the module's Install/Upgrade method(s):
    /// initializer.Installer
    ///     .Toolbox(CommonToolbox.PageWidgets)
    ///         .LoadOrAddSection(SectionName)
    ///             .SetTitle(SectionTitle) // When creating a new section
    ///             .SetDescription(SectionDescription) // When creating a new section
    ///             .LoadOrAddWidget<FootprintsReporter>("FootprintsReporter")
    ///                 .SetTitle("FootprintsReporter")
    ///                 .SetDescription("FootprintsReporter")
    ///                 .LocalizeUsing<ModuleResourceClass>() //Optional
    ///                 .SetCssClass(WidgetCssClass) // You can use a css class to add an icon (Optional)
    ///             .Done()
    ///         .Done()
    ///     .Done();
    /// </remarks>
    /// <see cref="http://www.sitefinity.com/documentation/documentationarticles/user-guide/widgets"/>
    [Telerik.Sitefinity.Web.UI.ControlDesign.ControlDesigner(typeof(SitefinityWebApp.Custom.Footprints.Designer.FootprintsReporterDesigner))]
    public class FootprintsReporter : SimpleView
    {
        #region Properties
        /// <summary>
        /// Gets or sets the message that will be displayed in the label.
        /// </summary>
        public Guid DetailsPageID { get; set; }
        public Guid MapLauncherPageID { get; set; }
        //public string FootprintDetailsPageUrl { get; set; }
        //public string FootprintsMapLauncherPageUrl { get; set; }

        public class Footprint
        {
            public string Title { get; set; }
            public string Name { get; set; }
            public string Date { get; set; }
            public string Location { get; set; }
            public string LaunchMap { get; set; }
        }

        /// <summary>
        /// Obsolete. Use LayoutTemplatePath instead.
        /// </summary>
        protected override string LayoutTemplateName
        {
            get
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Gets the layout template's relative or virtual path.
        /// </summary>
        public override string LayoutTemplatePath
        {
            get
            {
                if (string.IsNullOrEmpty(base.LayoutTemplatePath))
                    return FootprintsReporter.layoutTemplatePath;
                return base.LayoutTemplatePath;
            }
            set
            {
                base.LayoutTemplatePath = value;
            }
        }
        #endregion

        #region Control References
        /// <summary>
        /// Reference to the Label control that shows the Message.
        /// </summary>
        protected virtual HiddenField DetailsPageUrl
        {
            get
            {
                return this.Container.GetControl<HiddenField>("DetailsPageUrl", true);
            }
        }

        /// <summary>
        /// Reference to the Label control that shows the Message.
        /// </summary>
        protected virtual HiddenField MapLauncherPageUrl
        {
            get
            {
                return this.Container.GetControl<HiddenField>("MapLauncherPageUrl", true);
            }
        }

        /// <summary>
        /// Reference to the Literal control that shows text.
        /// </summary>
        protected virtual Button ExportData
        {
            get
            {
                return this.Container.GetControl<Button>("ExportData", true);
            }
        }

        #endregion

        #region Methods
        /// <summary>
        /// Initializes the controls.
        /// </summary>
        /// <param name="container"></param>
        /// <remarks>
        /// Initialize your controls in this method. Do not override CreateChildControls method.
        /// </remarks>
        protected override void InitializeControls(GenericContainer container)
        {
            if (DetailsPageID != Guid.Empty)
                DetailsPageUrl.Value = GetPageUrl(DetailsPageID);
            if (MapLauncherPageID != Guid.Empty)
                MapLauncherPageUrl.Value = GetPageUrl(MapLauncherPageID);

            Button exportData = this.ExportData;
            exportData.Click += ButtonClicked;
        }
                
        public IQueryable<DynamicContent> RetrieveCollectionOfFootprints()
        {
            var providerName = "OpenAccessProvider";
            DynamicModuleManager dynamicModuleManager = DynamicModuleManager.GetManager(providerName);
            Type footprintType = TypeResolutionService.ResolveType("Telerik.Sitefinity.DynamicTypes.Model.Footprints.Footprint");

            // This is how we get the collection of Footprint items
            var myCollection = dynamicModuleManager.GetDataItems(footprintType).Where(f => f.Status == ContentLifecycleStatus.Live).OrderByDescending(o => o.DateCreated);

            return myCollection;
        }

        protected void ButtonClicked(object sender, EventArgs e)
        {
            try
            {
                string comma = ",";
                StringBuilder exportBuilder = new StringBuilder();
                exportBuilder.Append("Title" + comma + "Name" + comma + "Date" + comma + "Street" + comma +
                    "City" + comma + "State" + comma + "Zip" + comma + "Country" + comma + "Summary" + System.Environment.NewLine);

                foreach (var footprintItem in RetrieveCollectionOfFootprints())
                {
                    var Address = footprintItem.GetAddressFields().First().Value;
                    exportBuilder.Append(footprintItem.GetValue<Lstring>("Title") + comma +
                        footprintItem.GetValue<Lstring>("Name") + comma +
                        footprintItem.DateCreated.ToShortTimeString() + comma +
                        Address.Street + comma +
                        Address.City + comma +
                        Address.StateCode + comma +
                        Address.Zip + comma +
                        Address.CountryCode + comma +
                        footprintItem.GetValue<Lstring>("Summary") +
                        System.Environment.NewLine);
                }

                if (exportBuilder.Length > 0)
                    WriteToCSV(exportBuilder);
            }
            catch { }
        }


        public static void WriteToCSV(StringBuilder exportBuilder)
        {
            try
            {
                DateTime time = DateTime.Now;              // Use current time
                string format = "MM_dd_yyyy";
                string fileName = "FootprintsData_" + time.ToString(format) + ".csv";
                string attachment = "attachment; filename=" + fileName;
                HttpContext.Current.Response.Clear();
                HttpContext.Current.Response.ClearHeaders();
                HttpContext.Current.Response.ClearContent();
                HttpContext.Current.Response.AddHeader("content-disposition", attachment);
                HttpContext.Current.Response.ContentType = "text/csv";
                HttpContext.Current.Response.AddHeader("Pragma", "public");
                HttpContext.Current.Response.Write(exportBuilder.ToString());
                HttpContext.Current.Response.End();
            }
            catch { }
        }

        public string GetPageUrl(Guid pageID)
        {
            var mgr = PageManager.GetManager();
            var pageNode = mgr.GetPageNode(pageID);
            string pageUrl = String.Empty;

            if (pageNode.GetFullUrl().Substring(0, 2) == "~/")
            {
                pageUrl = pageNode.GetFullUrl().Substring(2, pageNode.GetFullUrl().Length - 2);
            }
            else
            {
                pageUrl = pageNode.GetFullUrl();
            }
            return pageUrl;
        }

        #endregion

        #region Private members & constants
        public static readonly string layoutTemplatePath = "~/Custom/Footprints/FootprintsReporter.ascx";
        #endregion
    }
}
