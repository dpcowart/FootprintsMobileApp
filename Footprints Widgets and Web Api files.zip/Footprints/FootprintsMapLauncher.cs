﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using Telerik.Sitefinity.Web.UI;
using Telerik.Sitefinity.Security.Model;

namespace SitefinityWebApp.Custom.Footprints
{
    /// <summary>
    /// Class used to create custom page widget
    /// </summary>
    /// <remarks>
    /// If this widget is a part of a Sitefinity module,
    /// you can register it in the site's toolbox by adding this to the module's Install/Upgrade method(s):
    /// initializer.Installer
    ///     .Toolbox(CommonToolbox.PageWidgets)
    ///         .LoadOrAddSection(SectionName)
    ///             .SetTitle(SectionTitle) // When creating a new section
    ///             .SetDescription(SectionDescription) // When creating a new section
    ///             .LoadOrAddWidget<FootprintsMapLauncher>("FootprintsMapLauncher")
    ///                 .SetTitle("FootprintsMapLauncher")
    ///                 .SetDescription("FootprintsMapLauncher")
    ///                 .LocalizeUsing<ModuleResourceClass>() //Optional
    ///                 .SetCssClass(WidgetCssClass) // You can use a css class to add an icon (Optional)
    ///             .Done()
    ///         .Done()
    ///     .Done();
    /// </remarks>
    /// <see cref="http://www.sitefinity.com/documentation/documentationarticles/user-guide/widgets"/>
    [Telerik.Sitefinity.Web.UI.ControlDesign.ControlDesigner(typeof(SitefinityWebApp.Custom.Footprints.Designer.FootprintsMapLauncherDesigner))]
    public class FootprintsMapLauncher : SimpleView
    {
        #region Properties
        /// <summary>
        /// Gets or sets the message that will be displayed in the label.
        /// </summary>
        public string Message { get; set; }
        /// <summary>
        /// Obsolete. Use LayoutTemplatePath instead.
        /// </summary>
        protected override string LayoutTemplateName
        {
            get
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Gets the layout template's relative or virtual path.
        /// </summary>
        public override string LayoutTemplatePath
        {
            get
            {
                if (string.IsNullOrEmpty(base.LayoutTemplatePath))
                    return FootprintsMapLauncher.layoutTemplatePath;
                return base.LayoutTemplatePath;
            }
            set
            {
                base.LayoutTemplatePath = value;
            }
        }
        #endregion

        #region Control References
        /// <summary>
        /// Reference to the Label control that shows the Message.
        /// </summary>
        protected virtual Label MessageLabel
        {
            get
            {
                return this.Container.GetControl<Label>("MessageLabel", true);
            }
        }

        /// <summary>
        /// Reference to the Label control that shows the Message.
        /// </summary>
        protected virtual DropDownList FootprintUsers
        {
            get
            {
                return this.Container.GetControl<DropDownList>("FootprintUsers", true);
            }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Initializes the controls.
        /// </summary>
        /// <param name="container"></param>
        /// <remarks>
        /// Initialize your controls in this method. Do not override CreateChildControls method.
        /// </remarks>
        protected override void InitializeControls(GenericContainer container)
        {
            Label messageLabel = this.MessageLabel;
            Telerik.Sitefinity.Security.RoleManager roleManager = Telerik.Sitefinity.Security.RoleManager.GetManager();
            List<User> users = new List<User>();

            try
            {
                string userName = HttpContext.Current.Request.QueryString["name"];

                if (string.IsNullOrEmpty(this.Message))
                {
                    messageLabel.Text = "<h1>Footprints</h1>";
                }
                else
                {
                    messageLabel.Text = this.Message;
                }

                if (roleManager.RoleExists("Footprints"))
                {
                    users = roleManager.GetUsersInRole("Footprints").OrderBy(n => n.UserName).ToList();
                }

                FootprintUsers.Items.Add(new ListItem("SELECT"));
                FootprintUsers.Items.Add(new ListItem("ALL"));

                foreach (var user in users)
                {
                    FootprintUsers.Items.Add(new ListItem(user.UserName.ToUpper().Trim()));
                }
                if (!String.IsNullOrEmpty(userName))
                    FootprintUsers.SelectedIndex = FootprintUsers.Items.IndexOf(FootprintUsers.Items.FindByValue(userName.ToUpper().Trim()));
            }
            catch { }
        }

        #endregion

        #region Private members & constants
        public static readonly string layoutTemplatePath = "~/Custom/Footprints/FootprintsMapLauncher.ascx";
        #endregion
    }
}
