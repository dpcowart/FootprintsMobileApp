Type.registerNamespace("SitefinityWebApp.Custom.Footprints.Designer");

SitefinityWebApp.Custom.Footprints.Designer.FootprintsReporterDesigner = function (element) {
    /* Initialize DetailsPageID fields */
    this._pageSelectorDetailsPageID = null;
    this._selectorTagDetailsPageID = null;
    this._DetailsPageIDDialog = null;
 
    this._showPageSelectorDetailsPageIDDelegate = null;
    this._pageSelectedDetailsPageIDDelegate = null;
    
    /* Initialize MapLauncherPageID fields */
    this._pageSelectorMapLauncherPageID = null;
    this._selectorTagMapLauncherPageID = null;
    this._MapLauncherPageIDDialog = null;
 
    this._showPageSelectorMapLauncherPageIDDelegate = null;
    this._pageSelectedMapLauncherPageIDDelegate = null;
    
    /* Calls the base constructor */
    SitefinityWebApp.Custom.Footprints.Designer.FootprintsReporterDesigner.initializeBase(this, [element]);
}

SitefinityWebApp.Custom.Footprints.Designer.FootprintsReporterDesigner.prototype = {
    /* --------------------------------- set up and tear down --------------------------------- */
    initialize: function () {
        /* Here you can attach to events or do other initialization */
        SitefinityWebApp.Custom.Footprints.Designer.FootprintsReporterDesigner.callBaseMethod(this, 'initialize');

        /* Initialize DetailsPageID */
        this._showPageSelectorDetailsPageIDDelegate = Function.createDelegate(this, this._showPageSelectorDetailsPageIDHandler);
        $addHandler(this.get_pageSelectButtonDetailsPageID(), "click", this._showPageSelectorDetailsPageIDDelegate);

        this._pageSelectedDetailsPageIDDelegate = Function.createDelegate(this, this._pageSelectedDetailsPageIDHandler);
        this.get_pageSelectorDetailsPageID().add_doneClientSelection(this._pageSelectedDetailsPageIDDelegate);

        if (this._selectorTagDetailsPageID) {
            this._DetailsPageIDDialog = jQuery(this._selectorTagDetailsPageID).dialog({
                autoOpen: false,
                modal: false,
                width: 395,
                closeOnEscape: true,
                resizable: false,
                draggable: false,
                zIndex: 5000
            });
        }

        /* Initialize MapLauncherPageID */
        this._showPageSelectorMapLauncherPageIDDelegate = Function.createDelegate(this, this._showPageSelectorMapLauncherPageIDHandler);
        $addHandler(this.get_pageSelectButtonMapLauncherPageID(), "click", this._showPageSelectorMapLauncherPageIDDelegate);

        this._pageSelectedMapLauncherPageIDDelegate = Function.createDelegate(this, this._pageSelectedMapLauncherPageIDHandler);
        this.get_pageSelectorMapLauncherPageID().add_doneClientSelection(this._pageSelectedMapLauncherPageIDDelegate);

        if (this._selectorTagMapLauncherPageID) {
            this._MapLauncherPageIDDialog = jQuery(this._selectorTagMapLauncherPageID).dialog({
                autoOpen: false,
                modal: false,
                width: 395,
                closeOnEscape: true,
                resizable: false,
                draggable: false,
                zIndex: 5000
            });
        }
    },
    dispose: function () {
        /* this is the place to unbind/dispose the event handlers created in the initialize method */
        SitefinityWebApp.Custom.Footprints.Designer.FootprintsReporterDesigner.callBaseMethod(this, 'dispose');

        /* Dispose DetailsPageID */
        if (this._showPageSelectorDetailsPageIDDelegate) {
            $removeHandler(this.get_pageSelectButtonDetailsPageID(), "click", this._showPageSelectorDetailsPageIDDelegate);
            delete this._showPageSelectorDetailsPageIDDelegate;
        }

        if (this._pageSelectedDetailsPageIDDelegate) {
            this.get_pageSelectorDetailsPageID().remove_doneClientSelection(this._pageSelectedDetailsPageIDDelegate);
            delete this._pageSelectedDetailsPageIDDelegate;
        }

        /* Dispose MapLauncherPageID */
        if (this._showPageSelectorMapLauncherPageIDDelegate) {
            $removeHandler(this.get_pageSelectButtonMapLauncherPageID(), "click", this._showPageSelectorMapLauncherPageIDDelegate);
            delete this._showPageSelectorMapLauncherPageIDDelegate;
        }

        if (this._pageSelectedMapLauncherPageIDDelegate) {
            this.get_pageSelectorMapLauncherPageID().remove_doneClientSelection(this._pageSelectedMapLauncherPageIDDelegate);
            delete this._pageSelectedMapLauncherPageIDDelegate;
        }
    },

    /* --------------------------------- public methods ---------------------------------- */

    findElement: function (id) {
        var result = jQuery(this.get_element()).find("#" + id).get(0);
        return result;
    },

    /* Called when the designer window gets opened and here is place to "bind" your designer to the control properties */
    refreshUI: function () {
        var controlData = this._propertyEditor.get_control(); /* JavaScript clone of your control - all the control properties will be properties of the controlData too */

        /* RefreshUI DetailsPageID */
        if (controlData.DetailsPageID && controlData.DetailsPageID !== "00000000-0000-0000-0000-000000000000") {
            var pagesSelectorDetailsPageID = this.get_pageSelectorDetailsPageID().get_pageSelector();
            var selectedPageLabelDetailsPageID = this.get_selectedDetailsPageIDLabel();
            var selectedPageButtonDetailsPageID = this.get_pageSelectButtonDetailsPageID();
            pagesSelectorDetailsPageID.add_selectionApplied(function (o, args) {
                var selectedPage = pagesSelectorDetailsPageID.get_selectedItem();
                if (selectedPage) {
                    selectedPageLabelDetailsPageID.innerHTML = selectedPage.Title.Value;
                    jQuery(selectedPageLabelDetailsPageID).show();
                    selectedPageButtonDetailsPageID.innerHTML = '<span>Change</span>';
                }
            });
            pagesSelectorDetailsPageID.set_selectedItems([{ Id: controlData.DetailsPageID}]);
        }        

        /* RefreshUI MapLauncherPageID */
        if (controlData.MapLauncherPageID && controlData.MapLauncherPageID !== "00000000-0000-0000-0000-000000000000") {
            var pagesSelectorMapLauncherPageID = this.get_pageSelectorMapLauncherPageID().get_pageSelector();
            var selectedPageLabelMapLauncherPageID = this.get_selectedMapLauncherPageIDLabel();
            var selectedPageButtonMapLauncherPageID = this.get_pageSelectButtonMapLauncherPageID();
            pagesSelectorMapLauncherPageID.add_selectionApplied(function (o, args) {
                var selectedPage = pagesSelectorMapLauncherPageID.get_selectedItem();
                if (selectedPage) {
                    selectedPageLabelMapLauncherPageID.innerHTML = selectedPage.Title.Value;
                    jQuery(selectedPageLabelMapLauncherPageID).show();
                    selectedPageButtonMapLauncherPageID.innerHTML = '<span>Change</span>';
                }
            });
            pagesSelectorMapLauncherPageID.set_selectedItems([{ Id: controlData.MapLauncherPageID}]);
        }        
    },

    /* Called when the "Save" button is clicked. Here you can transfer the settings from the designer to the control */
    applyChanges: function () {
        var controlData = this._propertyEditor.get_control();

        /* ApplyChanges DetailsPageID */

        /* ApplyChanges MapLauncherPageID */
    },

    /* --------------------------------- event handlers ---------------------------------- */

    /* --------------------------------- private methods --------------------------------- */

    /* DetailsPageID private methods */
    _showPageSelectorDetailsPageIDHandler: function (selectedItem) {
        var controlData = this._propertyEditor.get_control();
        var pagesSelector = this.get_pageSelectorDetailsPageID().get_pageSelector();
        if (controlData.DetailsPageID) {
            pagesSelector.set_selectedItems([{ Id: controlData.DetailsPageID }]);
        }
        this._DetailsPageIDDialog.dialog("open");
        jQuery("#designerLayoutRoot").hide();
        this._DetailsPageIDDialog.dialog().parent().css("min-width", "355px");
        dialogBase.resizeToContent();
    },

    _pageSelectedDetailsPageIDHandler: function (items) {
        var controlData = this._propertyEditor.get_control();
        var pagesSelector = this.get_pageSelectorDetailsPageID().get_pageSelector();
        this._DetailsPageIDDialog.dialog("close");
        jQuery("#designerLayoutRoot").show();
        dialogBase.resizeToContent();
        if (items == null) {
            return;
        }
        var selectedPage = pagesSelector.get_selectedItem();
        if (selectedPage) {
            this.get_selectedDetailsPageIDLabel().innerHTML = selectedPage.Title.Value;
            jQuery(this.get_selectedDetailsPageIDLabel()).show();
            this.get_pageSelectButtonDetailsPageID().innerHTML = '<span>Change</span>';
            controlData.DetailsPageID = selectedPage.Id;
        }
        else {
            jQuery(this.get_selectedDetailsPageIDLabel()).hide();
            this.get_pageSelectButtonDetailsPageID().innerHTML = '<span>Select...</span>';
            controlData.DetailsPageID = "00000000-0000-0000-0000-000000000000";
        }
    },

    /* MapLauncherPageID private methods */
    _showPageSelectorMapLauncherPageIDHandler: function (selectedItem) {
        var controlData = this._propertyEditor.get_control();
        var pagesSelector = this.get_pageSelectorMapLauncherPageID().get_pageSelector();
        if (controlData.MapLauncherPageID) {
            pagesSelector.set_selectedItems([{ Id: controlData.MapLauncherPageID }]);
        }
        this._MapLauncherPageIDDialog.dialog("open");
        jQuery("#designerLayoutRoot").hide();
        this._MapLauncherPageIDDialog.dialog().parent().css("min-width", "355px");
        dialogBase.resizeToContent();
    },

    _pageSelectedMapLauncherPageIDHandler: function (items) {
        var controlData = this._propertyEditor.get_control();
        var pagesSelector = this.get_pageSelectorMapLauncherPageID().get_pageSelector();
        this._MapLauncherPageIDDialog.dialog("close");
        jQuery("#designerLayoutRoot").show();
        dialogBase.resizeToContent();
        if (items == null) {
            return;
        }
        var selectedPage = pagesSelector.get_selectedItem();
        if (selectedPage) {
            this.get_selectedMapLauncherPageIDLabel().innerHTML = selectedPage.Title.Value;
            jQuery(this.get_selectedMapLauncherPageIDLabel()).show();
            this.get_pageSelectButtonMapLauncherPageID().innerHTML = '<span>Change</span>';
            controlData.MapLauncherPageID = selectedPage.Id;
        }
        else {
            jQuery(this.get_selectedMapLauncherPageIDLabel()).hide();
            this.get_pageSelectButtonMapLauncherPageID().innerHTML = '<span>Select...</span>';
            controlData.MapLauncherPageID = "00000000-0000-0000-0000-000000000000";
        }
    },

    /* --------------------------------- properties -------------------------------------- */

    /* DetailsPageID properties */
    get_pageSelectButtonDetailsPageID: function () {
        if (this._pageSelectButtonDetailsPageID == null) {
            this._pageSelectButtonDetailsPageID = this.findElement("pageSelectButtonDetailsPageID");
        }
        return this._pageSelectButtonDetailsPageID;
    },
    get_selectedDetailsPageIDLabel: function () {
        if (this._selectedDetailsPageIDLabel == null) {
            this._selectedDetailsPageIDLabel = this.findElement("selectedDetailsPageIDLabel");
        }
        return this._selectedDetailsPageIDLabel;
    },
    get_pageSelectorDetailsPageID: function () {
        return this._pageSelectorDetailsPageID;
    },
    set_pageSelectorDetailsPageID: function (val) {
        this._pageSelectorDetailsPageID = val;
    },
    get_selectorTagDetailsPageID: function () {
        return this._selectorTagDetailsPageID;
    },
    set_selectorTagDetailsPageID: function (value) {
        this._selectorTagDetailsPageID = value;
    },

    /* MapLauncherPageID properties */
    get_pageSelectButtonMapLauncherPageID: function () {
        if (this._pageSelectButtonMapLauncherPageID == null) {
            this._pageSelectButtonMapLauncherPageID = this.findElement("pageSelectButtonMapLauncherPageID");
        }
        return this._pageSelectButtonMapLauncherPageID;
    },
    get_selectedMapLauncherPageIDLabel: function () {
        if (this._selectedMapLauncherPageIDLabel == null) {
            this._selectedMapLauncherPageIDLabel = this.findElement("selectedMapLauncherPageIDLabel");
        }
        return this._selectedMapLauncherPageIDLabel;
    },
    get_pageSelectorMapLauncherPageID: function () {
        return this._pageSelectorMapLauncherPageID;
    },
    set_pageSelectorMapLauncherPageID: function (val) {
        this._pageSelectorMapLauncherPageID = val;
    },
    get_selectorTagMapLauncherPageID: function () {
        return this._selectorTagMapLauncherPageID;
    },
    set_selectorTagMapLauncherPageID: function (value) {
        this._selectorTagMapLauncherPageID = value;
    }
}

SitefinityWebApp.Custom.Footprints.Designer.FootprintsReporterDesigner.registerClass('SitefinityWebApp.Custom.Footprints.Designer.FootprintsReporterDesigner', Telerik.Sitefinity.Web.UI.ControlDesign.ControlDesignerBase);
